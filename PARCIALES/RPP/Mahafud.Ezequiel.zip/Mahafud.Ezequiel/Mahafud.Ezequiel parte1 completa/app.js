var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Entidades;
(function (Entidades) {
    var Ropa = /** @class */ (function () {
        function Ropa(codigo, nombre, precio) {
            this.codigo = codigo;
            this.nombre = nombre;
            this.precio = precio;
        }
        Ropa.prototype.ToString = function () {
            return "\"codigo\" : " + this.codigo + ", \"nombre\" : \"" + this.nombre + "\", \"precio\": " + this.precio;
        };
        return Ropa;
    }());
    Entidades.Ropa = Ropa;
})(Entidades || (Entidades = {}));
var Entidades;
(function (Entidades) {
    var Campera = /** @class */ (function (_super) {
        __extends(Campera, _super);
        function Campera(codigo, nombre, precio, talle, color) {
            var _this = _super.call(this, codigo, nombre, precio) || this;
            _this.talle = talle;
            _this.color = color;
            return _this;
        }
        Campera.prototype.CamperaToJson = function () {
            return "{ " + this.ToString() + ", \"talle\" : \"" + this.talle + "\", \"color\" : \"" + this.color + "\" }";
        };
        Campera.prototype.GetCodigo = function () {
            return this.codigo;
        };
        Campera.prototype.GetTalle = function () {
            return this.talle;
        };
        return Campera;
    }(Entidades.Ropa));
    Entidades.Campera = Campera;
})(Entidades || (Entidades = {}));
var Test;
(function (Test) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.AgregarCampera = function () {
            // Traigo los valores de los inputs (si es necesario se convierte de string a number)
            var codigo = parseInt(document.getElementById("txtCodigo").value);
            var nombre = document.getElementById("txtNombre").value;
            var color = document.getElementById("cboColor").value;
            var talle = document.getElementById("txtTalle").value;
            var precio = parseInt(document.getElementById("txtPrecio").value);
            // Traigo el archivo
            //let archivo : any = (<HTMLInputElement> document.getElementById("foto"));
            // Tomo la extensión
            //let extension : string = archivo.value.split(".").pop();
            // Armo la ruta
            //let path : string = patente + '_' + marca + '.' + extension;
            // Creo el objeto
            var campera = new Entidades.Campera(codigo, nombre, precio, talle, color);
            // Creo un objeto de tipo formulario
            //let form : FormData = new FormData();
            // Creo una variable para el caso
            var caso = "agregar";
            // Dependiendo del valor del input hidden agrega o modifica el registro
            if (document.getElementById("hdnIdModificacion").value == "modificar") {
                caso = "modificar"; // Establezco el valor del caso a modificar
                /*if (!confirm(`Desea modificar la campera con codigo ${campera.GetCodigo()} y talle ${campera.GetTalle()}?`))
                    // Limpio el formulario
                    Test.Manejadora.LimpiarForm();
                    return 0;*/
            }
            // Seteo los valores en el form a enviar
            //form.append("foto", archivo.files[0]);
            //form.append("cadenaJson", campera.CamperaToJson());
            //form.append("caso", caso);
            // Creo el objeto AJAX estableciendo el método POST y el enctype para subida de archivos
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            //xhttp.setRequestHeader("enctype", "multipart/form-data");
            xhttp.send("caso=" + caso + "&cadenaJson=" + campera.CamperaToJson());
            // Muestro el spinner
            Test.Manejadora.AdministrarSpinner(true);
            // Si está todo bien, toma la respuesta y muestra el resultado
            xhttp.onreadystatechange = function () {
                if (xhttp.status == 200 && xhttp.readyState == 4) {
                    // Creo un objeto JSON de la respuesta y muestro el valor de TodoOK
                    var respuesta = JSON.parse(xhttp.responseText);
                    console.log('Formulario: ' + respuesta.TodoOK);
                    // Actualizo el listado
                    Test.Manejadora.MostrarCamperas();
                }
                // Si terminó la petición
                if (xhttp.readyState == 4) {
                    // Limpio el formulario
                    Test.Manejadora.LimpiarForm();
                    // Oculto el spinner
                    Test.Manejadora.AdministrarSpinner(false);
                }
            };
            return 1;
        };
        Manejadora.MostrarCamperas = function (filtro) {
            if (filtro === void 0) { filtro = "ninguno"; }
            // Creo el objeto AJAX estableciendo el método POST y el enctype correspondiente
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=mostrar");
            // Muestro el spinner
            Test.Manejadora.AdministrarSpinner(true);
            xhttp.onreadystatechange = function () {
                // Si está todo bien
                if (xhttp.status == 200 && xhttp.readyState == 4) {
                    // Guardo en un array de obj JSON la respuesta
                    var respuesta = JSON.parse(xhttp.responseText);
                    // Establezco el encabezado de la tabla
                    var tabla = "<table><tr><th>Código</th><th>Color</th><th>Nombre</th><th>Precio</th><th>Talle</th><th>Eliminar</th><th>Modificar</th></tr>";
                    // Recorro el array de JSON
                    for (var i = 0; i < respuesta.length; i++) {
                        if (filtro == respuesta[i].color || filtro == "ninguno") {
                            // Guardo una copia del JSON en formato string para transferirlo a otras funciones
                            var objJSON = JSON.stringify(respuesta[i]);
                            // Muestro la línea de datos del JSON
                            tabla += "<tr><td>" + respuesta[i].codigo + "</td><td>" + respuesta[i].color + "</td><td>" + respuesta[i].nombre + "</td><td>" + respuesta[i].precio + "</td><td>" + respuesta[i].talle + "</td>";
                            // Agrego botones para eliminar y modificar el registro
                            tabla += "<td><input type=\"button\" onclick='Test.Manejadora.EliminarCampera(" + objJSON + ")' value=\"Eliminar\"></td><td><input type=\"button\" onclick='Test.Manejadora.ModificarCampera(" + objJSON + ")' value=\"Modificar\"></td></tr>";
                        }
                    }
                    tabla += "</table>";
                    // Muestro la tabla en el div correspondiente
                    document.getElementById("divTabla").innerHTML = tabla;
                    // Oculto el spinner
                    Test.Manejadora.AdministrarSpinner(false);
                }
            };
        };
        Manejadora.EliminarCampera = function (objetoJSON) {
            if (confirm("Desea eliminar esta campera?")) {
                // Creo el objeto AJAX estableciendo el método POST y el enctype correspondiente
                var xhttp_1 = new XMLHttpRequest();
                xhttp_1.open("POST", "BACKEND/administrar.php", true);
                xhttp_1.setRequestHeader("content-type", "application/x-www-form-urlencoded");
                // Paso el objeto haciéndolo nuevamente string (ya que JS por defecto lo transforma a JSON)
                xhttp_1.send("caso=eliminar&cadenaJson=" + JSON.stringify(objetoJSON));
                // Muestro el spinner
                Test.Manejadora.AdministrarSpinner(true);
                xhttp_1.onreadystatechange = function () {
                    // Si está todo bien
                    if (xhttp_1.status == 200 && xhttp_1.readyState == 4) {
                        // Creo un objeto JSON de la respuesta y muestro el valor de TodoOK
                        var respuesta = JSON.parse(xhttp_1.responseText);
                        console.log(respuesta.TodoOK);
                        // Actualizo el listado
                        Test.Manejadora.MostrarCamperas();
                        // Oculto el spinner
                        Test.Manejadora.AdministrarSpinner(false);
                    }
                };
            }
        };
        Manejadora.ModificarCampera = function (objetoJSON) {
            // Hago nuevamente string el parámetro (ya que JS por defecto lo transforma a JSON)
            var objeto = JSON.stringify(objetoJSON);
            // Lo transformo nuevamente a objeto JSON
            objeto = JSON.parse(objeto);
            // Seteo los valores en los inputs
            document.getElementById("txtCodigo").value = String(objeto.codigo);
            document.getElementById("cboColor").value = objeto.color;
            document.getElementById("txtNombre").value = objeto.nombre;
            document.getElementById("txtPrecio").value = String(objeto.precio);
            document.getElementById("txtTalle").value = objeto.talle;
            // Muestro la foto
            //(<HTMLImageElement> document.getElementById("imgFoto")).src = 'BACKEND/fotos/' + objeto.foto;
            // Seteo como sólo lectura el identificador 
            document.getElementById("txtCodigo").readOnly = true;
            // Modifico el texto del botón de submit (AGREGAR ID EN FORM)
            document.getElementById("submit").value = "Modificar";
            // Seteo el valor del input hidden a "modificar"
            document.getElementById("hdnIdModificacion").value = "modificar";
        };
        Manejadora.CargarColoresJSON = function () {
            // Creo el objeto AJAX estableciendo el método POST y el enctype correspondiente
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", "BACKEND/administrar.php", true);
            xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhttp.send("caso=colores");
            // Muestro el spinner
            Test.Manejadora.AdministrarSpinner(true);
            xhttp.onreadystatechange = function () {
                // Si está todo bien
                if (xhttp.status == 200 && xhttp.readyState == 4) {
                    if (document.getElementById("cboColor").options.length < 4) {
                        // Guardo en un array los obj JSON
                        var respuesta = JSON.parse(xhttp.responseText);
                        // Recorro el array
                        for (var i = 0; i < respuesta.length; i++) {
                            // Creo un objeto de tipo HTMLOptionElement y le establezco el text y el ID del obj JSON
                            var opc = document.createElement("option");
                            opc.text = respuesta[i].descripcion;
                            // Agrego el objeto option al HTMLSelectElement
                            document.getElementById("cboColor").add(opc);
                        }
                    }
                    // Oculto el spinner
                    Test.Manejadora.AdministrarSpinner(false);
                }
            };
        };
        Manejadora.FiltrarCamperasPorColor = function () {
            // Tomo el valor del select y lo paso a la función Mostrar como filtro
            var color = document.getElementById("cboColor").value;
            Test.Manejadora.MostrarCamperas(color);
        };
        Manejadora.LimpiarForm = function () {
            // Seteo todos los inputs en su valor por defecto
            document.getElementById("txtCodigo").value = "";
            document.getElementById("txtNombre").value = "";
            document.getElementById("txtPrecio").value = "";
            document.getElementById("txtTalle").value = "";
            document.getElementById("cboColor").value = "Azul";
            //(<HTMLInputElement> document.getElementById("foto")).value = "";
            // Seteo nuevamente el identificador a modo editable
            document.getElementById("txtCodigo").readOnly = false;
            // Seteo el valor por defecto del botón submit
            document.getElementById("submit").value = "Agregar";
            // Seteo el valor por defecto del input hidden 
            document.getElementById("hdnIdModificacion").value = "";
            // Muestro la img por defecto
            //(<HTMLImageElement> document.getElementById("imgFoto")).src = 'BACKEND/auto_default.jpg';
        };
        Manejadora.AdministrarSpinner = function (mostrar) {
            var gif = "./BACKEND/gif-load.gif";
            var div = document.getElementById("divSpinner");
            var img = document.getElementById("imgSpinner");
            if (mostrar) {
                div.style.display = "block";
                div.style.top = "50%";
                div.style.left = "45%";
                img.src = gif;
            }
            if (!mostrar) {
                div.style.display = "none";
                img.src = "";
            }
        };
        return Manejadora;
    }());
    Test.Manejadora = Manejadora;
})(Test || (Test = {}));
