namespace Entidades {
    export class Campera extends Ropa {
        public talle : string;
        public color : string;

        public constructor(codigo:number, nombre:string, precio:number, talle:string, color:string) {
            super(codigo, nombre, precio);
            this.talle = talle;
            this.color = color;
        }

        public CamperaToJson() : string {
            return `{ ${this.ToString()}, "talle" : "${this.talle}", "color" : "${this.color}" }`;
        }

        public GetCodigo() {
            return this.codigo;
        }

        public GetTalle() {
            return this.talle;
        }
    }
}